﻿using Microsoft.AspNetCore.Components.Forms;

namespace LoymarkApp.Pages
{
    public partial class Activities
    {
        #region Variables

        private List<LoymarkApi.Estructuras.Clases.Usuarios> DataUsuarios;
        private LoymarkApi.Estructuras.Clases.Actividades Model;
        private List<LoymarkApi.Estructuras.Clases.Actividades> DataActividades;

        #endregion


        #region Methods

        protected override void OnInitialized()
        {
            Model = new LoymarkApi.Estructuras.Clases.Actividades();
            DataUsuarios = Data.Usuarios.GetListAll(config);
            DataActividades = Data.Actividades.GetList(config);

        }


        #endregion
    }
}
