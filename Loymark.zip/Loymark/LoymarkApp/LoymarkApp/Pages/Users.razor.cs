﻿using Microsoft.AspNetCore.Components.Forms;

namespace LoymarkApp.Pages
{
    public partial class Users
    {
        #region Variables

        private List<LoymarkApi.Estructuras.Clases.Usuarios> DataUsuarios;
        private LoymarkApi.Estructuras.Clases.Usuarios Model;
        private List<LoymarkApi.Estructuras.Clases.Paises> DataPaises;

        private bool MostrarLista = true;
        private string ModoEjecucion = "N";
        private EditContext editContext;

        #endregion


        #region Methods

        protected override void OnInitialized()
        {
            Model = new LoymarkApi.Estructuras.Clases.Usuarios();
            DataUsuarios = Data.Usuarios.GetList(config);
            DataPaises = Data.Paises.Get(config);

            editContext = new EditContext(Model);
        }

        private void LeerUsuario(int CodigoUsuario, string Modo)
        {
            if(CodigoUsuario == 0)
            {
                Model = new LoymarkApi.Estructuras.Clases.Usuarios() { 
                    FechaNacimientoUsuario = DateTime.Now, 
                    CodigoPaisResidencia = "CR" ,
                    Estado = true
                };
            }
            else
            {
                Model = LoymarkApp.Data.Usuarios.Get(CodigoUsuario, config);
            }
            
            editContext = new EditContext(Model);

            ModoEjecucion = Modo;
            MostrarLista = false;
        }

        private void Aceptar()
        {
            if (editContext.Validate())
            {
                switch (ModoEjecucion)
                {
                    case "A": LoymarkApp.Data.Usuarios.Add(Model, config); break;
                    case "M": LoymarkApp.Data.Usuarios.Update(Model, config); break;
                    case "E": LoymarkApp.Data.Usuarios.Delete(Model, config); break;
                }

                ModoEjecucion = "N";
                DataUsuarios = Data.Usuarios.GetList(config);
                MostrarLista = true;
            }
        }

        #endregion
    }
}
