﻿using System.Net.Http.Headers;
using System.Text;

namespace LoymarkApp.Data
{
    public static class Paises
    {
		public static List<LoymarkApi.Estructuras.Clases.Paises> Get(IConfiguration config)
		{
			HttpResponseMessage responseMessage;
			string urlString = config.GetValue<string>("LoymarkApiURL").Replace("{controller}", "Paises").Replace("{action}", "Get");
			var vUriUpload = new Uri(urlString);
			string request = "";

			using (var client = new HttpClient())
			{
				client.DefaultRequestHeaders.Accept.Clear();
				client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
				var tokenRequest = new HttpRequestMessage(HttpMethod.Post, vUriUpload);
				HttpContent httpContent = new StringContent("", Encoding.UTF8, "application/json");
				tokenRequest.Content = httpContent;
				responseMessage = client.SendAsync(tokenRequest).Result;
			}

			request = responseMessage.Content.ReadAsStringAsync().Result;
			var model = Newtonsoft.Json.JsonConvert.DeserializeObject<ResultApi>(request);
			if (responseMessage.StatusCode == System.Net.HttpStatusCode.OK)
			{
				var data = Newtonsoft.Json.JsonConvert.DeserializeObject<List<LoymarkApi.Estructuras.Clases.Paises>>(model.Message);
				return data;
			}
			else
			{
				throw new Exception(model.Message);
			}
		}

	}
}
