﻿namespace LoymarkApp.Data
{
    public class ResultApi
    {
        public string Status { get; set; }
        public string Message { get; set; }
    }
}
