using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Net.Mime;

namespace LoymarkApi
{
    [ApiController]
    [Route("[controller]")]
    public class PaisesController : ControllerBase
    {
        private readonly ILogger<PaisesController> _logger;
        private readonly LoymarkApi.Controladores.DataContext _dataContext;
        private readonly IConfiguration _config;

        public PaisesController(ILogger<PaisesController> logger, LoymarkApi.Controladores.DataContext dataContext, IConfiguration config)
        {
            _logger = logger;
            _dataContext = dataContext;
            _config = config;
        }

        [HttpPost("Get")]
        [Consumes(MediaTypeNames.Application.Json)]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(typeof(OkResult), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
        public async Task<ActionResult> Get()
        {
            List<LoymarkApi.Estructuras.Clases.Paises> paises = new List<LoymarkApi.Estructuras.Clases.Paises>();
            using (var httpClient = new HttpClient())
            {
                var json = await httpClient.GetStringAsync(_config.GetValue<string>("urlContries"));

                paises = Newtonsoft.Json.JsonConvert.DeserializeObject<List<LoymarkApi.Estructuras.Clases.Paises>>(json);
            }


            return Ok(new { Status = StatusCodes.Status200OK, Message = Newtonsoft.Json.JsonConvert.SerializeObject(paises) });
        }

    }
}