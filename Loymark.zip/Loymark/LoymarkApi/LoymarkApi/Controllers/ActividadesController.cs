using Microsoft.AspNetCore.Mvc;
using System.Net.Mime;

namespace LoymarkApi
{
    [ApiController]
    [Route("[controller]")]
    public class ActividadesController : ControllerBase
    {
        private readonly ILogger<ActividadesController> _logger;
        private readonly LoymarkApi.Controladores.DataContext _dataContext;

        public ActividadesController(ILogger<ActividadesController> logger, LoymarkApi.Controladores.DataContext dataContext)
        {
            _logger = logger;
            _dataContext = dataContext;
        }

		[HttpPost("Add")]
		[Consumes(MediaTypeNames.Application.Json)]
		[Produces(MediaTypeNames.Application.Json)]
		[ProducesResponseType(typeof(OkResult), StatusCodes.Status200OK)]
		[ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
		public ActionResult Add([FromBody] LoymarkApi.Estructuras.Clases.Actividades usuario)
		{

            _dataContext.Actividades.Add(usuario);
            _dataContext.SaveChanges();

            return Ok(new { Status = StatusCodes.Status200OK, Message = "ok" });
		}

        [HttpPost("Delete")]
        [Consumes(MediaTypeNames.Application.Json)]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(typeof(OkResult), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
        public ActionResult Delete([FromBody] LoymarkApi.Estructuras.Clases.Actividades usuario)
        {

            _dataContext.Actividades.Remove(usuario);
            _dataContext.SaveChanges();

            return Ok(new { Status = StatusCodes.Status200OK, Message = "ok" });
        }

        [HttpPost("Update")]
        [Consumes(MediaTypeNames.Application.Json)]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(typeof(OkResult), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
        public ActionResult Update([FromBody] LoymarkApi.Estructuras.Clases.Actividades usuario)
        {

            _dataContext.Actividades.Update(usuario);
            _dataContext.SaveChanges();

            return Ok(new { Status = StatusCodes.Status200OK, Message = "ok" });
        }

        [HttpPost("Get")]
        [Consumes(MediaTypeNames.Application.Json)]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(typeof(OkResult), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
        public ActionResult Get([FromBody] int key)
        {

           var activity =  _dataContext.Actividades.Find(key);

            return Ok(new { Status = StatusCodes.Status200OK, Message = Newtonsoft.Json.JsonConvert.SerializeObject(activity) });
        }

        [HttpPost("GetList")]
        [Consumes(MediaTypeNames.Application.Json)]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(typeof(OkResult), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
        public ActionResult GetList()
        {

            var activities = _dataContext.Actividades.OrderByDescending(m => m.FechaActividad).ToList();

            return Ok(new { Status = StatusCodes.Status200OK, Message = Newtonsoft.Json.JsonConvert.SerializeObject(activities) });
        }

    }
}