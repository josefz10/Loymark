using Microsoft.AspNetCore.Mvc;
using System.Net.Mime;

namespace LoymarkApi
{
    [ApiController]
    [Route("[controller]")]
    public class UsuariosController : ControllerBase
    {
        private readonly ILogger<UsuariosController> _logger;
        private readonly LoymarkApi.Controladores.DataContext _dataContext;

        public UsuariosController(ILogger<UsuariosController> logger, LoymarkApi.Controladores.DataContext dataContext)
        {
            _logger = logger;
            _dataContext = dataContext;
        }

		[HttpPost("Add")]
		[Consumes(MediaTypeNames.Application.Json)]
		[Produces(MediaTypeNames.Application.Json)]
		[ProducesResponseType(typeof(OkResult), StatusCodes.Status200OK)]
		[ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
		public ActionResult Add([FromBody] LoymarkApi.Estructuras.Clases.Usuarios usuario)
		{

            _dataContext.Usuarios.Add(usuario);
            _dataContext.SaveChanges();

            _dataContext.Actividades.Add(new Estructuras.Clases.Actividades()
            {
                CodigoUsuario = usuario.CodigoUsuario,
                FechaActividad = DateTime.Now,
                DescripcionActividad = "Creaci�n de Usuario"
            });
            _dataContext.SaveChanges();

            return Ok(new { Status = StatusCodes.Status200OK, Message = "ok" });
		}

        [HttpPost("Delete")]
        [Consumes(MediaTypeNames.Application.Json)]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(typeof(OkResult), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
        public ActionResult Delete([FromBody] LoymarkApi.Estructuras.Clases.Usuarios usuario)
        {
            usuario.Estado = false;
            _dataContext.Usuarios.Update(usuario);
            _dataContext.Actividades.Add(new Estructuras.Clases.Actividades()
            {
                CodigoUsuario = usuario.CodigoUsuario,
                FechaActividad = DateTime.Now,
                DescripcionActividad = "Eliminaci�n de Usuario"
            });
            _dataContext.SaveChanges();

            return Ok(new { Status = StatusCodes.Status200OK, Message = "ok" });
        }

        [HttpPost("Update")]
        [Consumes(MediaTypeNames.Application.Json)]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(typeof(OkResult), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
        public ActionResult Update([FromBody] LoymarkApi.Estructuras.Clases.Usuarios usuario)
        {

            _dataContext.Usuarios.Update(usuario);
            _dataContext.Actividades.Add(new Estructuras.Clases.Actividades()
            {
                CodigoUsuario = usuario.CodigoUsuario,
                FechaActividad = DateTime.Now,
                DescripcionActividad = "Modificaci�n de Usuario"
            });
            _dataContext.SaveChanges();

            return Ok(new { Status = StatusCodes.Status200OK, Message = "ok" });
        }

        [HttpPost("Get")]
        [Consumes(MediaTypeNames.Application.Json)]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(typeof(OkResult), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
        public ActionResult Get([FromBody] int key)
        {

           var user =  _dataContext.Usuarios.Find(key);

            return Ok(new { Status = StatusCodes.Status200OK, Message = Newtonsoft.Json.JsonConvert.SerializeObject(user) });
        }

        [HttpPost("GetList")]
        [Consumes(MediaTypeNames.Application.Json)]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(typeof(OkResult), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
        public ActionResult GetList()
        {

            var users = _dataContext.Usuarios.Where(m => m.Estado);

            return Ok(new { Status = StatusCodes.Status200OK, Message = Newtonsoft.Json.JsonConvert.SerializeObject(users) });
        }

        [HttpPost("GetListAll")]
        [Consumes(MediaTypeNames.Application.Json)]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(typeof(OkResult), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
        public ActionResult GetListAll()
        {

            var users = _dataContext.Usuarios.ToList();

            return Ok(new { Status = StatusCodes.Status200OK, Message = Newtonsoft.Json.JsonConvert.SerializeObject(users) });
        }

    }
}