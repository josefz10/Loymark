﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Clase para realizar el mapeo del JSON que contiene la lista de paises según ISO  ISO 3166-1
/// </summary>
namespace LoymarkApi.Estructuras.Clases
{
    public class Paises
    {
        public string Code { get; set; }
        public string Name { get; set; }
    }
}
