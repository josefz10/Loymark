﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoymarkApi.Estructuras.Clases
{
    /// <summary>
    /// Clase para realizar el mapeo de la tabla de base de datos  ACTIVIDADES
    /// 
    /// </summary>
    public class Actividades
    {
        [Key]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:n0}")]
        [Range(0, int.MaxValue, ErrorMessageResourceType = typeof(Resources.Resources), ErrorMessageResourceName = nameof(Resources.Resources.CodigoActividad_Rango))]
        [Required(ErrorMessageResourceType = typeof(Resources.Resources), ErrorMessageResourceName = nameof(Resources.Resources.CodigoActividad_Requerido))]
        [Display(ResourceType = typeof(Resources.Resources), Description = nameof(Resources.Resources.CodigoActividad), Name = nameof(Resources.Resources.CodigoActividad), AutoGenerateField = false)]
        public int CodigoActividad { get; set; }

        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:d}")]
        [Required(ErrorMessageResourceType = typeof(Resources.Resources), ErrorMessageResourceName = nameof(Resources.Resources.FechaActividad_Requerido))]
        [Display(ResourceType = typeof(Resources.Resources), Description = nameof(Resources.Resources.FechaActividad), Name = nameof(Resources.Resources.FechaActividad), AutoGenerateField = false)]
        public DateTime FechaActividad { get; set; }

        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:n0}")]
        [Range(0, int.MaxValue, ErrorMessageResourceType = typeof(Resources.Resources), ErrorMessageResourceName = nameof(Resources.Resources.CodigoUsuario_Rango))]
        [Required(ErrorMessageResourceType = typeof(Resources.Resources), ErrorMessageResourceName = nameof(Resources.Resources.CodigoUsuario_Requerido))]
        [Display(ResourceType = typeof(Resources.Resources), Description = nameof(Resources.Resources.CodigoUsuario), Name = nameof(Resources.Resources.CodigoUsuario), AutoGenerateField = false)]
        public int CodigoUsuario { get; set; }

        [StringLength(50, ErrorMessageResourceType = typeof(Resources.Resources), ErrorMessageResourceName = nameof(Resources.Resources.DescripcionActividad_Rango))]
        [Required(ErrorMessageResourceType = typeof(Resources.Resources), ErrorMessageResourceName = nameof(Resources.Resources.DescripcionActividad_Requerido))]
        [Display(ResourceType = typeof(Resources.Resources), Description = nameof(Resources.Resources.DescripcionActividad), Name = nameof(Resources.Resources.DescripcionActividad), AutoGenerateField = false)]
        public string DescripcionActividad { get; set; }
    }
}
