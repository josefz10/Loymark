﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LoymarkApi.Estructuras.Resources;


namespace LoymarkApi.Estructuras.Clases
{
    /// <summary>
    /// Clase para realizar el mapeo de la tabla de base de datos  USUARIOS
    /// </summary>
    public class Usuarios
    {
        [Key]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:n0}")]
        [Range(0, int.MaxValue, ErrorMessageResourceType = typeof(Resources.Resources), ErrorMessageResourceName = nameof(Resources.Resources.CodigoUsuario_Rango))]
        [Required(ErrorMessageResourceType = typeof(Resources.Resources), ErrorMessageResourceName = nameof(Resources.Resources.CodigoUsuario_Requerido))]
        [Display(ResourceType = typeof(Resources.Resources), Description = nameof(Resources.Resources.CodigoUsuario), Name = nameof(Resources.Resources.CodigoUsuario), AutoGenerateField = false)]
        public int CodigoUsuario { get; set; }

        [StringLength(250, ErrorMessageResourceType = typeof(Resources.Resources), ErrorMessageResourceName = nameof(Resources.Resources.NombreUsuario_Rango))]
        [Required(ErrorMessageResourceType = typeof(Resources.Resources), ErrorMessageResourceName = nameof(Resources.Resources.NombreUsuario_Requerido))]
        [Display(ResourceType = typeof(Resources.Resources), Description = nameof(Resources.Resources.NombreUsuario), Name = nameof(Resources.Resources.NombreUsuario), AutoGenerateField = true)]
        public string NombreUsuario { get; set; }

        [StringLength(250, ErrorMessageResourceType = typeof(Resources.Resources), ErrorMessageResourceName = nameof(Resources.Resources.ApellidosUsuario_Rango))]
        [Required(ErrorMessageResourceType = typeof(Resources.Resources), ErrorMessageResourceName = nameof(Resources.Resources.ApellidosUsuario_Requerido))]
        [Display(ResourceType = typeof(Resources.Resources), Description = nameof(Resources.Resources.ApellidosUsuario), Name = nameof(Resources.Resources.ApellidosUsuario), AutoGenerateField = true)]
        public string ApellidosUsuario { get; set; }

        [StringLength(150, ErrorMessageResourceType = typeof(Resources.Resources), ErrorMessageResourceName = nameof(Resources.Resources.CorreoUsuario_Rango))]
        [Required(ErrorMessageResourceType = typeof(Resources.Resources), ErrorMessageResourceName = nameof(Resources.Resources.CorreoUsuario_Requerido))]
        [Display(ResourceType = typeof(Resources.Resources), Description = nameof(Resources.Resources.CorreoUsuario), Name = nameof(Resources.Resources.CorreoUsuario), AutoGenerateField = true)]
        [EmailAddress(ErrorMessageResourceType = typeof(Resources.Resources), ErrorMessageResourceName = nameof(Resources.Resources.CorreoUsuario_Email))]
        public string CorreoUsuario { get; set; }

        [Range(typeof(DateTime), "1900-01-01", "2100-01-01", ErrorMessageResourceType = typeof(Resources.Resources), ErrorMessageResourceName = nameof(Resources.Resources.FechaNacimientoUsuario_Rango))]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:d}")]
        [Required(ErrorMessageResourceType = typeof(Resources.Resources), ErrorMessageResourceName = nameof(Resources.Resources.FechaNacimientoUsuario_Requerido))]
        [Display(ResourceType = typeof(Resources.Resources), Description = nameof(Resources.Resources.FechaNacimientoUsuario), Name = nameof(Resources.Resources.FechaNacimientoUsuario), AutoGenerateField = false)]        
        public DateTime FechaNacimientoUsuario { get; set; }

        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:n0}")]
        [Range(0, int.MaxValue, ErrorMessageResourceType = typeof(Resources.Resources), ErrorMessageResourceName = nameof(Resources.Resources.TelefonoUsuario_Rango))]
        [Display(ResourceType = typeof(Resources.Resources), Description = nameof(Resources.Resources.TelefonoUsuario), Name = nameof(Resources.Resources.TelefonoUsuario), AutoGenerateField = false)]
        public int? TelefonoUsuario { get; set; }

        [StringLength(2, ErrorMessageResourceType = typeof(Resources.Resources), ErrorMessageResourceName = nameof(Resources.Resources.CodigoPaisResidencia_Requerido))]
        [Required(ErrorMessageResourceType = typeof(Resources.Resources), ErrorMessageResourceName = nameof(Resources.Resources.CodigoPaisResidencia_Requerido))]
        [Display(ResourceType = typeof(Resources.Resources), Description = nameof(Resources.Resources.CodigoPaisResidencia), Name = nameof(Resources.Resources.CodigoPaisResidencia), AutoGenerateField = false)]
        public string CodigoPaisResidencia { get; set; }

        [Display(ResourceType = typeof(Resources.Resources), Description = nameof(Resources.Resources.RecibirInformacion), Name = nameof(Resources.Resources.RecibirInformacion), AutoGenerateField = false)]
        public bool RecibirInformacion { get; set; }

        public bool Estado { get; set; }

    }
}
