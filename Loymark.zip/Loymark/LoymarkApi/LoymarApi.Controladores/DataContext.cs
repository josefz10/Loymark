﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoymarkApi.Controladores
{
    public class DataContext : DbContext
    {
        public DbSet<LoymarkApi.Estructuras.Clases.Usuarios> Usuarios { get; set; }
        public DbSet<LoymarkApi.Estructuras.Clases.Actividades> Actividades { get; set; }

        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {
        }
    }
}
